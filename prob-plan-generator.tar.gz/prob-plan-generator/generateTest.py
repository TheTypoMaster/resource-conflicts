import sys, os
f = open('full_plan.dat','r')
full_plan = f.read()
f.close()

f = open('obs.dat','w')
f.close()
steps = full_plan.split('\n')
for i in range(len(steps)-1):
    f = open('obs.dat','a')
    f.write(str(steps[i])+'\n')
    f.close()
    cmd = 'tar -jcvf test_' + str(i+1) + '.tar.bz2 obs.dat hyps.dat real_hyp.dat domain.pddl template.pddl'
    os.system(cmd)

print 'DONE'
