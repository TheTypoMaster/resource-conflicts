f = open('full_plan.dat','w')
f.close()

f = open('local_report.txt','r')
raw_text = f.read()
lines = raw_text.split("\n")
f.close()

flag = False
f = open('full_plan.dat','a')

for line in lines:
	
	if "Plan length:" in line:
		flag = False	
	
	if flag:
		f.write(str(line.split("(")[0][:-1])+'\n')

	if "Actual search time:" in line:
		flag = True 

f.close()

